ISARN Skills V1.22.15 resource pack.

The virtual menu title applies the ISARN font only to the shell glyph. The
following normal title component remains on the vanilla font. The shell glyph
uses ascent 6 so its bitmap top is aligned to the container top and its full
168/222 pixel canvas covers the corresponding generic 9x3/9x6 container.
The shell is compensated by -8 pixels before the bitmap and +8 pixels after
it, correcting the vanilla generic-container title origin at leftPos + 8.
This pack does not replace vanilla container textures, slot highlights, or
core shaders.
