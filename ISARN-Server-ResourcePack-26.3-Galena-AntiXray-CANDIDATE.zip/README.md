Use this directory as the server resource pack for ISARNPortals V1.4.4.

The pack contains the exact supplied 16x512, 32-frame animated portal texture at `assets/isarn/textures/block/portal.png` and the `isarn:portal_surface` item model.
